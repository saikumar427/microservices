package com.sai.microservices.netfixeurekanamingserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetfixEurekaNamingServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetfixEurekaNamingServerApplication.class, args);
	}

}
