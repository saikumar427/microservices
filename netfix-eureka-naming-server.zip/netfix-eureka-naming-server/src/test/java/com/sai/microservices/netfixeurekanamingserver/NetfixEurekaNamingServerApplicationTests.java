package com.sai.microservices.netfixeurekanamingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetfixEurekaNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
